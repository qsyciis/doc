package com.ucpaas.im.as.util;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.google.gson.Gson;

/**
 * json字符串工具类
 * 
 * @author xiejiaan
 */
@SuppressWarnings("unchecked")
public class JsonUtils {
	private static final Logger logger = LoggerFactory.getLogger(JsonUtils.class);
	private static final Gson gson = new Gson();

	/**
	 * 将对象转换成为json字符串
	 * 
	 * @param obj
	 * @return
	 */
	public static String toJson(Object obj) {
		return gson.toJson(obj);
	}

	/**
	 * 将json字符串转换成为对象
	 * 
	 * @param str
	 * @param classOfT
	 * @return
	 */
	public static <T> T toObject(String str, Class<T> classOfT) {
		try {
			return gson.fromJson(str, classOfT);
		} catch (Throwable e) {
			logger.error("【将json字符串转换成为对象】失败：str=" + str + ", classOfT=" + classOfT, e);
		}
		return null;
	}

	/**
	 * 将json字符串转换成为Map
	 * 
	 * @param str
	 * @return
	 */
	public static Map<String, Object> toMap(String str) {
		return toObject(str, Map.class);
	}

	/**
	 * <pre>
	 * 将json字符串转换成为对象
	 * 示例：toObject("{\"a\":{\"b\":{\"b1\":\"11\",\"b2\":\"22\"}}}", Map.class, "a", "b")
	 * </pre>
	 * 
	 * @param str
	 * @param classOfT
	 * @param path
	 *            对象路径
	 * @return
	 */
	public static <T> T toObject(String str, Class<T> classOfT, String... path) {
		Object obj = toObject(str, Object.class);
		for (String p : path) {
			if (!(obj instanceof Map)) {
				return null;
			}
			obj = ((Map<String, Object>) obj).get(p);
		}
		if (obj == null) {
			return null;
		}
		String result = toJson(obj);
		return toObject(result, classOfT);
	}

	public static void main(String[] args) {
		Map<String, Object> map = JsonUtils.toMap(null);
		map = JsonUtils.toMap("");
		map = JsonUtils.toMap("aa");

		String str = "{resultcode:0,result:[]}";
		map = JsonUtils.toMap(str);
		String resultcode = map.get("resultcode").toString();
		System.out.println(map);
		System.out.println(resultcode);
		System.out.println(resultcode.equals("0.0"));
		System.out.println(toObject("{\"a\":{\"b\":{\"b1\":\"11\",\"b2\":\"22\"}}}", Map.class, "a", "b"));
	}

}
