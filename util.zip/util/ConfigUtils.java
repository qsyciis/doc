package com.ucpaas.im.as.util;

import java.io.FileInputStream;
import java.lang.reflect.Field;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.PostConstruct;
import javax.servlet.ServletContext;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.context.ServletContextAware;

/**
 * 系统配置工具类
 * 
 * @author xiejiaan
 */
@Component
public class ConfigUtils implements ServletContextAware {
	private static final Logger logger = LoggerFactory.getLogger(ConfigUtils.class);

	/**
	 * <pre>
	 * 运行环境：development（开发）、devtest（开发测试）、test（测试）、production（线上测试demo）、proActivity（线上正式demo）
	 * </pre>
	 */
	public static String spring_profiles_active;
	/**
	 * 配置文件路径
	 */
	public static String config_file_path;

	/**
	 * client-rest接口地址
	 */
	public static String client_rest_url;
	/**
	 * im-rest接口地址
	 */
	public static String im_rest_url;

	/**
	 * 主账户id
	 */
	public static String sid;
	/**
	 * 账户授权令牌
	 */
	public static String token;
	/**
	 * 应用id
	 */
	public static String app_sid;
	
	/**
	 * voip登录验证码有效时间
	 */
	public static Integer authcode_expire;
	
	/**
	 * voip账户默认金额
	 */
	public static Long voip_default_balance;
	
	public static String sms_rest_url;
	public static String sms_templateId;
	public static String sms_sid;
	public static String sms_token;
	public static String sms_app_sid;
	public static Integer voip_charge_free;
	//im-as的应用id
	public static String old_imas_appid;
	
	//每次允许通话时长
	public static Long allowed_calltime;

	

	/**
	 * 初始化
	 */
	@PostConstruct
	public void init() {
		String path = ConfigUtils.class.getClassLoader().getResource("").getPath() + "config/";
		spring_profiles_active = System.getProperty("spring.profiles.active");
		config_file_path = path + "config_" + spring_profiles_active + ".properties";

		logger.debug("\n\n-------------------------【im-as，{}服务器启动】\n加载配置文件：\n{}\n", spring_profiles_active,
				config_file_path);

		initValue();
	}

	@Override
	public void setServletContext(ServletContext servletContext) {
		String ctx = servletContext.getContextPath();
		servletContext.setAttribute("ctx", ctx);
		logger.debug("加载配置：ctx={}", ctx);
	}

	/**
	 * 初始化配置项的值
	 */
	private void initValue() {
		Field[] fields = ConfigUtils.class.getFields();
		Object fieldValue = null;
		String name = null, value = null, tmp = null;
		Class<?> type = null;
		Pattern pattern = Pattern.compile("\\$\\{(.+?)\\}");
		Matcher matcher = null;
		try {
			Properties properties = new Properties();
			properties.load(new FileInputStream(config_file_path));

			for (Field field : fields) {
				name = field.getName();
				value = properties.getProperty(name);
				if (StringUtils.isNotBlank(value)) {
					matcher = pattern.matcher(value);
					while (matcher.find()) {
						tmp = properties.getProperty(matcher.group(1));
						if (StringUtils.isBlank(tmp)) {
							logger.error("配置{}存在其它配置{}，请检查您的配置文件", name, matcher.group(1));
						}
						value = value.replace(matcher.group(0), tmp);
					}

					type = field.getType();
					if (String.class.equals(type)) {
						fieldValue = value;
					} else if (Integer.class.equals(type)) {
						fieldValue = Integer.valueOf(value);
					} else if (Boolean.class.equals(type)) {
						fieldValue = Boolean.valueOf(value);
					} else if (Long.class.equals(type)) {
						fieldValue = Long.valueOf(value);
					} else {
						fieldValue = value;
					}
					field.set(this, fieldValue);
				}
				logger.debug("加载配置：{}={}", name, field.get(this));
			}
		} catch (Throwable e) {
			logger.error("初始化配置项的值失败：" + name + "=" + value, e);
		}
	}

}
