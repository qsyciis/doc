package com.ucpaas.im.as.util.rest;

import java.util.HashMap;
import java.util.Map;

import com.ucpaas.im.as.model.rest.RestResult;
import com.ucpaas.im.as.util.ConfigUtils;

/**
 * rest接口工具类
 * 
 * @author xiejiaan
 */
public class RestUtils {
	/**
	 * client-rest接口地址
	 */
	private static String client_rest_url = ConfigUtils.client_rest_url;
	/**
	 * im-rest接口地址
	 */
	private static String im_rest_url = ConfigUtils.im_rest_url;
	/**
	 * 主账户id
	 */
	private static String sid = ConfigUtils.sid;
	/**
	 * 账户授权令牌
	 */
	private static String token = ConfigUtils.token;

	/**
	 * 注册client
	 * 
	 * @param userId
	 *            用户id
	 * @param friendlyName
	 *            Client名称
	 * @param mobile
	 *            绑定的手机号码
	 * @return
	 */
	public static RestResult regClient(String userId, String friendlyName, String mobile,String appid) {
		Map<String, Object> value = new HashMap<String, Object>();
		value.put("appId", appid);
		value.put("userId", userId);
		value.put("friendlyName", friendlyName);
		value.put("mobile", mobile);
		return RestBaseUtils.post(client_rest_url, "/Clients", sid, token, "client", value);
	}

	/**
	 * 创建群组
	 * 
	 * @param userId
	 *            用户id
	 * @param groupId
	 *            群组id
	 * @param groupName
	 *            群组名称
	 * @return
	 */
	public static RestResult createGroup(String userId, String groupId, String groupName,String appid) {
		Map<String, Object> value = new HashMap<String, Object>();
		value.put("appId", appid);
		value.put("userId", userId);
		value.put("groupId", groupId);
		value.put("groupName", groupName);
		return RestBaseUtils.post(im_rest_url, "/im/group/createGroup", sid, token, "imGroup", value);
	}

	/**
	 * 加入群组
	 * 
	 * @param userId
	 *            用户id
	 * @param groupId
	 *            群组id
	 * @return
	 */
	public static RestResult joinGroup(String userId, String groupId,String appid) {
		Map<String, Object> value = new HashMap<String, Object>();
		value.put("appId", appid);
		value.put("userId", userId);
		value.put("groupId", groupId);
		return RestBaseUtils.post(im_rest_url, "/im/group/joinGroupBatch", sid, token, "imGroup", value);
	}

	/**
	 * 退出群组
	 * 
	 * @param userId
	 *            用户id
	 * @param groupId
	 *            群组id
	 * @return
	 */
	public static RestResult quitGroup(String userId, String groupId,String appid) {
		Map<String, Object> value = new HashMap<String, Object>();
		value.put("appId", appid);
		value.put("userId", userId);
		value.put("groupId", groupId);
		return RestBaseUtils.post(im_rest_url, "/im/group/quitGroup", sid, token, "imGroup", value);
	}

}
