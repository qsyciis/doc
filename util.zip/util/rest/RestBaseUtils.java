package com.ucpaas.im.as.util.rest;

import java.io.ByteArrayInputStream;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.http.Consts;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.client.fluent.Request;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.BasicHttpEntity;
import org.apache.http.entity.ContentType;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.util.EntityUtils;
import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ucpaas.im.as.model.rest.RestResult;
import com.ucpaas.im.as.util.JsonUtils;
import com.ucpaas.im.as.util.encrypt.EncryptUtils;

/**
 * rest接口基础工具类
 * 
 * @author xiejiaan
 */
@SuppressWarnings("all")
public class RestBaseUtils {
	private static final Logger logger = LoggerFactory.getLogger(RestBaseUtils.class);
	private static final int get = 1;
	private static final int post = 2;
	private static final int json = 1;
	private static final int xml = 2;

	/**
	 * 请求rest接口
	 * 
	 * @param requestMethod
	 *            请求方式，1：get，2：post
	 * @param requestDataType
	 *            请求数据类型，1：json，2：xml
	 * @param restUrl
	 *            rest接口地址
	 * @param operate
	 *            操作
	 * @param sid
	 *            主账号id
	 * @param token
	 *            主账号token
	 * @param key
	 *            post提交的数据key
	 * @param value
	 *            提交的数据
	 * @return
	 */
	public static RestResult request(int requestMethod, int requestDataType, String restUrl, String operate,
			String sid, String token, String key, Map<String, Object> value) {
		String timestamp = DateTime.now().toString("yyyyMMddHHmmss");// 时间戳
		String signature = EncryptUtils.encodeMd5(sid + token + timestamp).toUpperCase();// url签名：md5(主账户Id+主账户授权令牌+时间戳)
		String auth = EncryptUtils.encodeBase64(sid + ":" + timestamp);// base64(主账户Id+冒号+时间戳)
		StringBuilder sb = new StringBuilder();// 构造请求的url
		sb.append(restUrl);
		sb.append(sid);
		sb.append(operate);
		sb.append("?sig=");
		sb.append(signature);

		String url = null;
		String content = null;
		Double duration = null;
		String result = null;
		String exception = null;
		ContentType contentType = null;
		try {
			if (requestMethod == get) {
				for (Map.Entry<String, Object> v : value.entrySet()) {
					if (v.getValue() != null) {
						sb.append("&");
						sb.append(v.getKey());
						sb.append("=");
						sb.append(URLEncoder.encode(v.getValue().toString(), "utf-8"));
					}
				}
			} else {
				if (requestDataType == json) {
					Map<String, Object> json = new HashMap<String, Object>();
					json.put(key, value);
					content = JsonUtils.toJson(json);
				} else {
					StringBuilder xml = new StringBuilder();
					xml.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><");
					xml.append(key);
					xml.append(">");
					for (Map.Entry<String, Object> v : value.entrySet()) {
						if (v.getValue() != null) {
							xml.append("<");
							xml.append(v.getKey());
							xml.append(">");
							xml.append(v.getValue().toString());
							xml.append("</");
							xml.append(v.getKey());
							xml.append(">");
						}
					}
					xml.append("</");
					xml.append(key);
					xml.append(">");
					content = xml.toString();
				}
			}
			if (requestDataType == json) {
				contentType = ContentType.APPLICATION_JSON;
			} else {
				contentType = ContentType.create("application/xml", Consts.UTF_8);
			}
			url = sb.toString();
			Header[] headerArray = { new BasicHeader("Accept", contentType.getMimeType()),
					new BasicHeader("Content-Type", contentType.toString()), new BasicHeader("Authorization", auth) };

			logger.debug("【请求rest接口】开始：url={}, content={}", url, content);
			long startTime = System.currentTimeMillis();

			Pattern p = Pattern.compile("^https://([\\d\\.]+):(\\d+)/");// https://113.31.89.144:443/2014-06-30/Accounts/
			Matcher m = p.matcher(restUrl);
			if (m.find()) {// 没有证书的https地址
				String ip = m.group(1);
				int port = Integer.parseInt(m.group(2));
				DefaultHttpClient httpClient = SslUtils.getHttpClient(ip, port);
				HttpEntity entity = null;

				if (requestMethod == get) {
					HttpGet httpGet = new HttpGet(url);
					httpGet.setHeaders(headerArray);
					entity = httpClient.execute(httpGet).getEntity();
				} else {
					BasicHttpEntity requestBody = new BasicHttpEntity();
					requestBody.setContent(new ByteArrayInputStream(content.getBytes("utf-8")));
					requestBody.setContentLength(content.getBytes("utf-8").length);
					HttpPost httpPost = new HttpPost(url);
					httpPost.setHeaders(headerArray);
					httpPost.setEntity(requestBody);
					entity = httpClient.execute(httpPost).getEntity();
				}
				if (entity != null) {
					result = EntityUtils.toString(entity, "utf-8");
					EntityUtils.consume(entity);
				}
				httpClient.close();

			} else {
				Request request = null;
				if (requestMethod == get) {
					request = Request.Get(url);
				} else {
					request = Request.Post(url);
					request.bodyString(content, contentType);
				}
				request.setHeaders(headerArray);
				result = request.execute().returnContent().asString();
				if (result != null) {
					result = new String(result.getBytes("iso-8859-1"), "utf-8");
				}
			}

			duration = (System.currentTimeMillis() - startTime) / 1000.0;
			logger.debug("【请求rest接口】结束：duration={}秒, result={}", duration, result);
		} catch (Throwable e) {
			logger.error("【请求rest接口】失败：url=" + url + ", content=" + content, e);
			exception = e.getMessage();
		}

		boolean success = false;
		String respCode = JsonUtils.toObject(result, String.class, "resp", "respCode");
		if ("000000".equals(respCode)) {
			success = true;
		}
		RestResult restResult = new RestResult();
		restResult.setUrl(url);// 请求地址
		restResult.setContent(content);// 请求数据
		restResult.setDuration(duration);// 响应时长（秒）
		restResult.setResult(result);// 响应结果
		restResult.setException(exception);// 异常信息
		restResult.setSuccess(success);// 是否成功
		if (!success) {
			logger.error("【请求rest接口】返回失败：restResult={}", restResult);
		}
		return restResult;
	}

	/**
	 * get方式请求rest接口
	 * 
	 * @param restUrl
	 *            rest接口地址
	 * @param operate
	 *            操作
	 * @param sid
	 *            主账号id
	 * @param token
	 *            主账号token
	 * @param value
	 *            提交的数据
	 * @return
	 */
	public static RestResult get(String restUrl, String operate, String sid, String token, Map<String, Object> value) {
		return request(get, json, restUrl, operate, sid, token, null, value);
	}

	/**
	 * post方式请求rest接口
	 * 
	 * @param restUrl
	 *            rest接口地址
	 * @param operate
	 *            操作
	 * @param sid
	 *            主账号id
	 * @param token
	 *            主账号token
	 * @param key
	 *            post提交的数据key
	 * @param value
	 *            提交的数据
	 * @return
	 */
	public static RestResult post(String restUrl, String operate, String sid, String token, String key,
			Map<String, Object> value) {
		return request(post, json, restUrl, operate, sid, token, key, value);
	}

	public static void main(String[] args) {
		String restUrl = "http://121.201.55.70:8825/2014-06-30/Accounts/";
		String sid = "cce25ec101fc12087516bc6564d0aa73";
		String token = "623683e02b7156e103db1d4f854db336";
		Map<String, Object> value = new HashMap<String, Object>();
		value.put("appId", "0e0ad5c8ba5c4225b9eff2f4c0259196");
		value.put("clientNumber", "64471030000310");
		RestBaseUtils.get(restUrl, "/Clients", sid, token, value);// get请求：Client信息查询（Client号码）

		value = new HashMap<String, Object>();
		value.put("appId", "0e0ad5c8ba5c4225b9eff2f4c0259196");
		value.put("start", "0");
		value.put("limit", "2");
		// RestBaseUtils.post(restUrl, "/clientList", sid, token, "client",
		// value);// post请求：获取Client账号
	}

}
